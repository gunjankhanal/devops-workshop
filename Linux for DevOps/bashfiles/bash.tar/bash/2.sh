#!/bin/bash

echo "This is the first bash I created" 
