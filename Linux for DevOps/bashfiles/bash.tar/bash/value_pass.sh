#!/bin/bash


echo $0 $1 $2 $3
echo $#
echo $@

echo $*

