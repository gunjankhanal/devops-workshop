#!/bin/bash

: ' 
this is a comment
this is a comment
this is a comment
this is a comment
this is a comment
this is a comment
this is a comment
this is a comment
this is a comment
this is a comment

cat >> file4.txt 
# A comment just added 
# New comment
