#!/bin/bash

ls -al >file_b 2>&1

# or ls -al >& file_b
