#!/bin/bash

if [[ file3.txt -nt file2.txt ]]
then 
	echo "FILE3 is newer than FILE2"
else
	echo "FILE2 is newer than FILE3"
fi
