#!/bin/bash


cat << created
This is the text
new line has been added
created

# A comment just added 
# New comment
